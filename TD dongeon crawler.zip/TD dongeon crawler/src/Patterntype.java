public enum Patterntype {
    BACK_AND_FORTH,SQUARE
}
