import java.awt.*;

public class Camera {
    double x;
        private double y;  // Position de la caméra (coin supérieur gauche)
    private int width, height;  // Dimensions de la fenêtre d'affichage
    private int levelWidth, levelHeight;  // Dimensions du niveau (en pixels)

    public Camera(int width, int height) {
        this.width = width;
        this.height = height;
        this.x = 0;
        this.y = 0; 
    }

    // Met à jour la position de la caméra pour suivre le héros
    public void follow(Hero hero) {
        double heroX = hero.getX();
        double heroY = hero.getY();

        // Calcule le centre du héros
        double heroCenterX = heroX + hero.getWidth() / 2;
        double heroCenterY = heroY + hero.getHeight() / 2;

        // Calcule le centre de la caméra
        double cameraCenterX = x + width / 2;
        double cameraCenterY = y + height / 2;

        // Si le héros est trop près du bord gauche, déplace la caméra vers la gauche
        if (heroCenterX < cameraCenterX) {
            x = heroCenterX - width / 2;
        }
        // Si le héros est trop près du bord droit, déplace la caméra vers la droite
        else if (heroCenterX > cameraCenterX) {
            x = heroCenterX - width / 2;
        }

        // Si le héros est trop près du bord supérieur, déplace la caméra vers le haut
        if (heroCenterY < cameraCenterY) {
            y = heroCenterY - height / 2;
        }
        // Si le héros est trop près du bord inférieur, déplace la caméra vers le bas
        else if (heroCenterY > cameraCenterY) {
            y = heroCenterY - height / 2;
        }

        // Empêcher la caméra de sortir des limites du niveau
        if (x < 0) {
            x = 0;
        }
        if (y < 0) {
            y = 0;
        }

        // Empêcher la caméra de sortir de la zone du niveau (bas et droite)
        if (x + width > levelWidth) {
            x = levelWidth - width;
        }
        if (y + height > levelHeight) {
            y = levelHeight - height;
        }
    }

    // Définit les limites du niveau
    public void setBounds(int levelWidth, int levelHeight) {
        this.levelWidth = levelWidth;
        this.levelHeight = levelHeight;
    }

    // Applique la transformation pour le rendu des éléments (déplace les objets en fonction de la caméra)
    public void apply(Graphics2D g2d) {
        g2d.translate(-x, -y);  // Applique un déplacement en fonction de la position de la caméra
    }

    // Getter pour obtenir la position actuelle de la caméra
    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }
}
